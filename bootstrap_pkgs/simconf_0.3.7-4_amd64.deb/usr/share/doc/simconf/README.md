# Simconf
_Making your package configuration simple_

## Documentation

Basic documentation can be viewed by running the following commands:
- `simconf --help`
- `simconf toml-to-template --help`
- `simconf execute-templates --help`
- `simconf purge --help`

More details about simconf's sub-commands below.

### Generating question templates

The `toml-to-template` is a means to create a debconf question templates file using the `.toml` format instead of
debconf's native "rfc822-like" format. The basic format is like so:

```
default_language = "{language_id}"
[config."{question_id}"]
type = "{question_type}"
description."{language_id}" = "Basic description\nMore details here"
default = "default value here (optional)"
```
Where...
- `{language_id}`: A lowercase ISO 639-1 language code, with an optional underscore followed uppercase ISO 3166-
  alpha-2 country code. For example, `en`, `en_CA`, `pt_BR`. Note that if you only have a single translation for a
  language, you should _only_ use the language code.
- `{question_id}`: A debconf question/template identifier. These are a series of strings that can only contain the
  charactes in the range `a-z`, `A-Z`, `0-9`, `+`, `.`, `_`, and `-`, with `/` seperators. Debconf uses a single
  database for all config options, so it is expected that the first segment match the package name. For example, if
  your package is named `my-app`, the question/template identifier prepended with `my-app/`.
- `config.description."{language_id}"`: This is the string which will actually get displayed to the user, depending on
  their configured locale. The specified `default_language` will be used if the language doesn't match the user's
  configured locale. If newlines are used here, the debconf front-end may use the first line as the basic description
  for the item and subsiquent lines as an extended description. Description may contains placeholer, following the
  format `${placeholder_name}` when can be set in your config template.
- `config."{question_id}.type"`: This corresponds to debconf's own template types. This controls how the debconf
  front-end displays or handles the item.
  - `string`: a generic text input
    - The `default` value in this case can be any string
  - `password`: a generic text input, but the string is hidden/redacted from the user as they are typing. If you use
    this type, you should probably set the value to a blank string after getting this input, as all user inputs are
    stored unencrypted on the system.
    - The `default` value in this case can be any string
  - `boolean`: displayed as a yes/no prompt if displayed on its own or sometimes as a checkbox if in an input group.
    - The `default` value in this case can be `true` or `false
  - `select`: displays a list an options where the user has one choice. Debconf internally uses as a commas as
    seperators, so options and descriptions must not contain commas. If an option must contain a comma, you can
    url-encode your option and use the `urldecode` filter in the template. Details on how to specify options are below.
    - The `default` value in this must be one of the values in the specified list
  - `multiselect`: displays a list of options where the user can select multiple choices. Debconf internally uses as a
    commas as seperators, so options and descriptions must not contain commas. If an option must contain a comma, you
    can url-encode your option and use the `urldecode` filter in the template. Details on how to specify options are
    below.
    - The `default` value in this case must be an array where each item is one of the values in the specified list

When it comes to `select` or `multiselect` types, their options can be specified like the following examples:
```toml
[config."my-package/my-config-option"]
type = { "select" = [
  { value = "option1", description.en = "First option" },
  { value = "option2", description.en = "Second option" },
  { value = "option3", description.en = "Third option" },
]}
description.en = "Basic description\nMore details here"
default = "option1"
```
or, also
```toml
[config."my-package/my-config-option"]
description.en = "Basic description\nMore details here"
description.fr = "Description simple\nIndiquez les détails ici"
default = ["option1", "option2"]

# This array notation may be more manageable if you have multiple languages.
[[config."my-package/my-config-option".type.multiselect]]
value = "option1"
description.en = "First option"
description.fr = "Premier choix"

[[config."my-package/my-config-option".type.multiselect]]
value = "option2"
description.en = "Second option"
description.fr = "Deuxième choix"

[[config."my-package/my-config-option".type.multiselect]]
value = "option3"
description.en = "Third option"
description.fr = "Troisième choix"
```

### Generating config files

The `execute-templates` subcommand searches the specified `IN_DIR` for files ending in `.tera`, though files ending in
`.inc.tera` are not included in this search.

These [tera templates](https://keats.github.io/tera/) are executed with
the resulting file being written to `OUT_DIR` with the same sub-path relative to `IN_DIR` with the `.tera` suffix
removed.

For example, if `simconf execute-templates /usr/share/my-templates /etc/my-config` is executed, and the files
`/usr/share/my-templates/config.conf.tera` and `/usr/share/my-templates/inner/extra-config.conf.tera` exist, then the
files `/etc/my-config/config.conf` and `/etc/my-config/inner/extra-config.conf` are created.

Simconf adds the following filters to tera:
- `escape_str`: escapes the string according to Rust's string escaping rules
- `urldecode`: the inverse of Tera's built-in `urlencode` function, converts percent-encoded strings into UTF8.
- `toml_encode`: takes an object and encodes it as toml snippet
  - `pretty`: if a boolean and `true`, then pretty formatting will be used.
- `toml_encode_value`: encodes a toml value, unlike `toml_encode`, this is intended to be used anywhere the key is
  explicitly set by the template, for example, `my_key = {{ my_value | toml_encode_value }}`.

"Question identifiers" and "template identifiers" are similar, but not quite the same. "template identifiers" are
specified by your packages "templates" file. Each template automatically has an associated debconf database entry
with a matching question identifier. However, your template can define new questions, as in, entries in the debconf
database, using pre-existing templates. [You can find more information about debconf templates and their types here](https://manpages.debian.org/bullseye/debconf-doc/debconf-devel.7.en.html#Type)

Simconf adds the following functions to tera:
- `question_group`: Defines a question group. This is will be used to generate a "page" for the installer, which will
  be displayed when `get_answer` is called on an unanswered question. Questions not associated with a group occupy a
  page all on their own.
  - `title` (`string`, optional): Specifies a template to use to generate the window title.
  - `title_string` (`string`, optional): Specifies a literal string for the window title.
  - `group`: (`(string | group)[]`): An array of question identifiers or sub-groups. It is assumed by simconf that a 
    question will not be in more than one group. If you wish to re-use a template for multiple questions, use the
    `register_question` function.
    - Question identifiers can also have an optional "priority" suffix, which can be "@low", "@medium", "@high", or
      "@critical", defaulting to "@medium" if unspecified. Questions will not show to the user if debconf's configured
      priority is higher than what's specified. However, having a "@critical" suffix doesn't guarantee that a human
      will know of your question, as your package may be configured in a non-interactive environment. For example,
      automated updates or as part of cloud-init. The debconf development manual suggests the following when deciding
      on a priority.
      - `@low`: "Very trivial items that have defaults that will work in the vast majority of cases; only control
        freaks see these."
      - `@medium`: "Normal items that have reasonable defaults."
      - `@high`: "Items that don't have a reasonable default. (This is the default on most systems)"
      - `@critical`: "Items that will probably break the system without user intervention."
        - AT: I intepret this to mean "leaving the system in an unusable/unbootable state" if you're worried about your
          _app_ breaking, I suggest using `@high`.
  - returns: `null`
- `get_answer`: Gets the answer to a question. The question will be shown to the user as part of its group if it hasn't
  been seen before and if its priority is greater than or equal to the system's configured minimum. After attempting to
  get an answer, you use the `question_skipped` function to check whether or not it was actually shown to the user.
  - `q`: (`string`) The question identifier to use. If this question isn't a part of a question group, you may specify
    a priority suffix here. If the question is already in a group, the priority suffix will be ignored.
  - returns: The current value of the question, though the type is specific on the template type.
    - (non-existent questions): `null`
    - `boolean`: `boolean`. If this is unanswered with no default answer defined in the question template, this will be
      `false`.
	  - `multiselect`: an array of strings representing the selected choices. If this is unanswered with
      no default answer defined in the question template, this will be an empty array.
	  - (types without inputs): `null`.
	  - (all others): `string`. If this is unanswered with no default answer defined in the question template, it will be
      `""`.
- `get_answer_array`: This is the most magic/opinionated simconf function. Debconf doesn't provide a built-in means of
  having the user enter an arbitrarily-lengthed array of items, so this function was made to provide this
  functionality. The length of the array is asked first, afterwhich every value of the array is asked in a single
  input group.
  - `q_prefix`: (`string`) A question identifier to use as a prefix for the actual questions and templates to be used.
    to get the length of the resulting array, this function will use append `.amount` to this prefix, and get the
    answer from that. A priority suffix may be specified here, however, if `{q_prefix}.amount` is already in an input
    group, then that priority will be used instead.
  - `nonempty`: (`boolean`, optional) If `true`, then the value of `{q_prefix}.amount` must be an integer grater than 
    0. If `false` or unspecified, it must be a integer greater than or equal to 0.
  - `amount_invalid_message`: (`string`, optional) an error message to show if the amount is invalid.
  - `q_object_keys`: (`string[]`, optional) If specified, then the result will be an array of objects, where the keys
    are the strings in the array.
    - Each object will use the `{q_prefix}.template.{object_key}` template to ask the
      `{q_prefix}.{array_index}.{object_key}` question.
    - Otherwise, each array item will use the `{q_prefix}.template` template to ask the `{q_prefix}.{array_index}`
      question.
  - `q_index_placeholder` (`string`, optional): The placeholder name to replace with the array item index. Defaults to
    `index`
  - `q_index_start_at_1`: (`boolean`, optional): If `true`, then `1` will be added to the `q_index_placeholder`.
  - `q_title` (`string`, optional): Specifies a template to use to generate the window title when asking for the values
    of the array.
  - `q_title_string` (`string`, optional): Specifies a literal string for the window title when asking for the values
    of the array.
  - returns: An array of answers or objects with the specified keys with their values being the answers. The value
    types of the answers follow the same rules as the `get_answer` function result.
- `set_answer`: does what it says
  - `q`: (`string`) The question identifier to use.
  - `a`: (`string | string[] | boolean | number`) the value to set the answer to. If you specify an array of strings, make sure it doesn't have commas.
  - returns: `null`
- `question_exists`: Returns `true` if the question has been registered, `false` otherwise.
  - `q`: (`string`) The question identifier to use.
  - returns: `boolean`
- `go_back`: Template execution is halted and restarted from the beginning with the current answers retained. All
  question groups except for the ones specified by the `until` parameter will be skipped.
    - `until` a question identifier used to look up a question group to "go back" to. If unspecified, this defaults to
      the most-recent question group.
    - `message` a question identifier to show before going back. This is intended to be used to show an error message
      or similar.
    - returns: `!`: This function never returns, as the template execution is halted.
- `reset_question`: Resets the question to its default (or empty) values. All flags will also be reset. It'll be as if
  this question was never asked before.
  - `q`: (`string`) The question identifier to reset.
  - returns: `null`
- `set_template_placeholder`: Question templates can have placeholder values which can be substituted at runtime. They
  follow for format `${placeholder_name}`. This function allows you to set what string to substitute for a given
  question.
  - `q`: (`string`) The question identifier set the placeholder value to.
  - `placeholder`: (`string`) The placeholder's name.
  - `value`: (`string`) The string to show the user where the placeholder was.
  - returns: `null`
- `get_flag`: Gets a question's flag. A common flag is `"seen"`, which can be used to check if the question was shown
  to the user before,
  - `q`: (`string`) The question to fetch the flags of
  - `flag`: (`string`) The name of the flag to get
  - returns: `boolean`: The current value of the flag
- `set_flag`: Sets a question's flag.
  - `q`: (`string`) The question to set the flag of
  - `flag`: (`string`) The name of the flag to set
  - `value`: `boolean`: The value to set the flag to
  - returns: `null`
- `register_question`: Creates a new question using a pre-existing template
  - `q`: (`string`) A question identifier representing the new question to create
  - `template`: (`string`) A template identifier to use with the new question
- `unregister_question`: Removes a question from debconf's database
  - `q`: (`string`) A question identifier to remove
- `question_seen`: Checks whether or not the question was seen. Note that this is always reset to `false` any time
  `dpkg-reconfigure` is ran.
  - `q`: (`string`) The question potentially seen
  - returns: `boolean`: `true` if the question was seen, false otherwise.
- `question_skipped`: Checks whether a question was skipped. This may be due to your question being a lower priority
  than what's required, or due to debconf being in an non-interactive environment. This can be used to avoid infinite
  loops in attempting to re-ask questions with invalid answers which the user cannot actually see.
  - `q`: (`string`) The question potentially skipped
  - returns: `boolean`: `true` if the question was sent to debconf yet debconf did not show to show it to the user,
    `false` otherwise. This will always return `false` if `get_answer` for the specified `q` was not called yet.
- `is_file`: Checks if the specified path is a file
  - `path`: (`string`) path to the potential file
  - returns: `boolean`: `true` if the path in question is confirmed to be a file `false` otherwise. This also returns
    `false` if any errors occured while checking.
- `is_dir`: Checks if the specified path is a directory
  - `path`: (`string`) path to the potential directory
  - returns: `boolean`: `true` if the path in question is confirmed to be a directory `false` otherwise. This also
    return `false` if any errors occured while checking.
- `read_file_to_string`: does what it says
  - `path`: (`string`) path to the file
  - returns: `string` if the file could be read and contained valid UTF8, `null` otherwise.

### Using this as part of your install scripts

You can add simconf to your debian maintainer scripts like so:
```sh
# DEBIAN/config
if [ "$1" = "reconfigure" ]; then
  # Marker for postinst later
  touch "/tmp/my-package.reconfigure";
fi;
```
```sh
# DEBIAN/postinst
if [ "$1" = "configure" ]; then
  if [ -z "${SIMCONF_STATUS:-}" ]; then
    # Stuff to do before simconf executes here
    exec -a "$0" simconf execute-templates \
      $(if [ -f "/tmp/my-package.reconfigure" ]; then echo "--reconfigure"; fi) \
      --exec-deb-script \
      "/usr/share/my-package/simconf" \
      "/etc/my-package" \
      -- "$@";
  fi;
  rm -f "/tmp/my-package.reconfigure" || true;
  # Stuff to do before after executes here
fi;
```
```sh
# DEBIAN/postrm
if [ "$1" = "purge" ]; then
  if [ -z "${SIMCONF_STATUS:-}" ]; then
    # Stuff to do before simconf executes here
    exec -a "$0" simconf purge \
      --exec-deb-script \
      -- "$@";
  fi;
  # Stuff to do before after executes here
fi;
```

Note that you can use simconf during the `config` stage, but if your config templates are within the package, they may not exist at the time simconf is ran. Plus, running simconf in the `config` stage requires simconf to be in your `pre-depends` list, which is apparently taboo or something.

### Using this as a library

The simconf crate can be imported as a library by using the exported `simconf_command` function. This can be useful for
generating/validating your template files in your `build.rs` script.
